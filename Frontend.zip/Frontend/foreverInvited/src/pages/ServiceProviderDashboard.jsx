import React from "react";

const ServiceProviderDashboard = () => {
  return (
    <div>
      <h2>Service Provider Dashboard</h2>
      <p>Welcome to the Service Provider Dashboard!</p>
    </div>
  );
};

export default ServiceProviderDashboard;
