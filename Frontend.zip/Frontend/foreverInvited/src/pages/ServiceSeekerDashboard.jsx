import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import './DashboardStyles.css'; // Import the CSS styles for the dashboard

const ServiceSeekerDashboard = () => {
  const [user, setUser] = useState(null); // Store user data
  const navigate = useNavigate();

  // Fetch the logged-in user's data (email and username)
  useEffect(() => {
    // Assuming the logged-in user is stored in localStorage after login
    const loggedInUser = localStorage.getItem("user"); // Get user info from localStorage

    if (loggedInUser) {
      setUser(JSON.parse(loggedInUser)); // Set the user data from localStorage
    } else {
      navigate("/login"); // Redirect to login if user is not found
    }
  }, [navigate]);

  const handleChoosePlan = () => {
    navigate("/choose-plan"); // Navigate to the choose plan page
  };

  return (
    <div className="dashboard-container">
      <nav className="navbar">
        <img src="/images/ForeverInvited.png" alt="Forever Invited" className="logo" />
        <div className="navbar-links">
          <a href="/dashboard">Dashboard</a>
          <a href="/profile">Profile</a>
          <a href="/logout">Logout</a>
        </div>
      </nav>
      <div className="dashboard-content">
        <h1>Welcome, {user ? user.username : 'User'}!</h1>
        <p>Plan your wedding with us!</p>
        <p>Email: {user ? user.email : 'Not Available'}</p>
        <button onClick={handleChoosePlan} className="choose-plan-button">
          Choose Your Plan
        </button>
      </div>
    </div>
  );
};

export default ServiceSeekerDashboard;
