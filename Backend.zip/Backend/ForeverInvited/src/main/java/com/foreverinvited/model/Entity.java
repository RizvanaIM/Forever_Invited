package com.foreverinvited.model;

public @interface Entity {

}
