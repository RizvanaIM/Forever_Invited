package com.foreverinvited.controller;

import com.foreverinvited.model.User;
import com.foreverinvited.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    // Admin approves service provider
    @PostMapping("/admin/approve")
    public ResponseEntity<String> approveServiceProvider(@RequestParam String email) {
        Optional<User> userOptional = userRepository.findById(email);

        // Using Optional's .orElse() to get the user or null
        User user = userOptional.orElse(null);

        if (user != null && user.getRole().equals("Service provider") && !user.isApproved()) {
            user.setApproved(true);
            userRepository.save(user);
            return ResponseEntity.ok("Service provider approved successfully.");
        } else {
            return ResponseEntity.badRequest().body("Service provider not found or already approved.");
        }
    }

    // Admin rejects service provider
    @PostMapping("/admin/reject")
    public ResponseEntity<String> rejectServiceProvider(@RequestParam String email) {
        Optional<User> userOptional = userRepository.findById(email);

        // Using Optional's .orElse() to get the user or null
        User user = userOptional.orElse(null);

        if (user != null && user.getRole().equals("Service provider") && !user.isApproved()) {
            userRepository.delete(user);
            return ResponseEntity.ok("Service provider rejected and removed.");
        } else {
            return ResponseEntity.badRequest().body("Service provider not found or already approved.");
        }
    }
}
