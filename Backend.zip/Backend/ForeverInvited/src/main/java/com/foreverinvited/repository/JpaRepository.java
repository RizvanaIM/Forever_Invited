package com.foreverinvited.repository;


public interface JpaRepository<T1, T2> {

}
