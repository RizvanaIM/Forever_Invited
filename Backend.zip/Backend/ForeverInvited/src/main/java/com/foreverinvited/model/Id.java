package com.foreverinvited.model;

public @interface Id {

}
