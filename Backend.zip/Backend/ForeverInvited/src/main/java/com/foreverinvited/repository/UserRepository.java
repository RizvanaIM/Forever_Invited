package com.foreverinvited.repository;

import com.foreverinvited.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
    // Find user by email (since email is the primary key)
}
