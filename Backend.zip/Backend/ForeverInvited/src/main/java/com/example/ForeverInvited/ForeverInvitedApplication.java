package com.example.ForeverInvited;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForeverInvitedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForeverInvitedApplication.class, args);
	}

}
