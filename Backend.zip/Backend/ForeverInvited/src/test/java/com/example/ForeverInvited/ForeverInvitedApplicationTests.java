package com.example.ForeverInvited;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForeverInvitedApplicationTests {

	@Test
	void contextLoads() {
	}

}
