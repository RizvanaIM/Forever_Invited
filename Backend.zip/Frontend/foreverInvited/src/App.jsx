import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import RegistrationPage from "./pages/RegistrationPage"; // Import your RegistrationPage component
import AdminDashboardPage from "./pages/AdminDashboardPage";
import LoginPage from "./pages/LoginPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import AdminDashboard from "./pages/AdminDashboard";
import ServiceSeekerDashboard from "./pages/ServiceSeekerDashboard";
import ServiceProviderDashboard from "./pages/ServiceProviderDashboard";
import HomePage from "./components/HomePage";

function App() {
  return (
    <Router>
      <Routes>
        {/* Define your route path and the component */}
        <Route path="/Home" element={<HomePage/>} />
        <Route path="/register" element={<RegistrationPage />} />
        <Route path="/admin" element={<AdminDashboardPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/resetpassword" element={<ResetPasswordPage/>} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/admindash" element={<AdminDashboard />} />
        <Route path="/ssdash" element={<ServiceSeekerDashboard />} />
        <Route path="/spdash" element={<ServiceProviderDashboard />} />

        {/* Add other routes as necessary */}
      </Routes>
    </Router>
  );
}

export default App;
