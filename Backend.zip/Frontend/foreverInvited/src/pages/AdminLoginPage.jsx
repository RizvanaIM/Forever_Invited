import React, { useState } from 'react';

const AdminLoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    fetch("http://localhost:8080/api/admin/login?email=" + email + "&password=" + password, {
      method: "POST",
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.message === "Admin login successful") {
          alert("Login successful!");
          // Redirect to Admin Dashboard
        } else {
          setError("Invalid admin credentials");
        }
      })
      .catch((err) => setError("Error logging in"));
  };

  return (
    <div className="admin-login">
      <h2>Admin Login</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleLogin}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          required
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required
        />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default AdminLoginPage;
