import React from "react";

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Welcome to the Admin Dashboard!</p>
    </div>
  );
};

export default AdminDashboard;
